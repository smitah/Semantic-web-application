package team8;

public class InputClass {
	private String _name;
	private String _job;
	private String _ethnicity;
	private String _gender;
	private int _age;
	private String _education;
	
	public String geteducation() {
		return _education;
	}
	public void seteducation(String _education) {
		this._education = _education;
	}
	public String getName() {
		return _name;
	}
	public void setName(String _name) {
		this._name = _name;
	}
	public String getJob() {
		return _job;
	}
	public void setJob(String _job) {
		this._job = _job;
	}
	public String getEthnicity() {
		return _ethnicity;
	}
	public void setEthnicity(String _ethnicity) {
		this._ethnicity = _ethnicity;
	}
	public String getGender() {
		return _gender;
	}
	public void setGender(String _gender) {
		this._gender = _gender;
	}
	public int getAge() {
		return _age;
	}
	public void setAge(int _age) {
		this._age = _age;
	}
}

