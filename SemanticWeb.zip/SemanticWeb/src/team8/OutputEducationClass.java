package team8;

public class OutputEducationClass {
	private  String educationLevel;
	private  int incomeGender;
	private  int incomeEthnicity;
	private  int incomeAgeGroup;
	
	public  String getEducationLevel() {
		return educationLevel;
	}
	public  void setEducationLevel(String EducationLevel) {
		educationLevel = EducationLevel;
	}
	public  int getIncomeGender() {
		return incomeGender;
	}
	public  void setIncomeGender(int IncomeGender) {
		incomeGender = IncomeGender;
	}
	public  int getIncomeEthnicity() {
		return incomeEthnicity;
	}
	public  void setIncomeEthnicity(int IncomeEthnicity) {
		incomeEthnicity = IncomeEthnicity;
	}
	public  int getIncomeAgeGroup() {
		return incomeAgeGroup;
	}
	public  void setIncomeAgeGroup(int IncomeAgeGroup) {
		incomeAgeGroup = IncomeAgeGroup;
	}	

}
